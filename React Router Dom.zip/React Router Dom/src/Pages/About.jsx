function About() {
    return <h2>This is About Page</h2>;
  }
  
  export default About;
  