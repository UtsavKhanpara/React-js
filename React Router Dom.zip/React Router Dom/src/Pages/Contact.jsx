function Contact() {
    return <h2>This is Contact Page</h2>;
  }
  
  export default Contact;
  