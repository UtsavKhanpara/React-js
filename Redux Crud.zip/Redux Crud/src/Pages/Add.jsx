import React, { useState } from 'react'
import { useDispatch } from 'react-redux';
import { Link, useNavigate } from 'react-router-dom'
import { ADD_USER } from '../Redux/Action/CrudAction';

const Add = () => {

  const[name,setName]=useState("");
  const[age, setAge]=useState("");
  const[email,setEmail]=useState("");

  const dispatch=useDispatch();
  const navigate=useNavigate();

  const handleSubmit=(e)=>{
    e.preventDefault();

    let obj={
      id:Math.floor(Math.random()*100000),
      name,
      age,
      email
    }
    dispatch(ADD_USER(obj));
    navigate('/view')
  }
  return (
    <div align="center">
      <h1>Add User</h1>
      <form onSubmit={handleSubmit}>
        <table border={1} cellPadding="5px" cellSpacing="5px">
          <tbody>
            <tr>
              <td>Name:-</td>
              <td><input type="text" placeholder='Enter Name' value={name} onChange={(e)=>setName(e.target.value)} /></td>
            </tr>
            <tr>
              <td>Email:-</td>
              <td><input type="email" placeholder='Enter Email' value={email} onChange={(e)=>setEmail(e.target.value)} /></td>
            </tr>
            <tr>
              <td>Age:-</td>
              <td><input type="number" placeholder='Enter Age' value={age} onChange={(e)=>setAge(e.target.value)} /></td>
            </tr>
            <tr>
              <td>⮞⮞⮞</td>
              <td><input type="submit" value="ADD" /></td>
            </tr>
          </tbody>
        </table>
      </form>
      <hr />
      <Link to={'/view'}>VIEW</Link>
    </div>
  )
}

export default Add
