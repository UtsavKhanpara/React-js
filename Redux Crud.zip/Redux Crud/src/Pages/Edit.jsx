import React, { useEffect, useState } from 'react'
import { Link, useLocation, useNavigate } from 'react-router-dom'
import { EDIT_USER } from '../Redux/Action/CrudAction';
import { useDispatch } from 'react-redux';

const Edit = () => {

  const [name, setName] = useState("");
  const [age, setAge] = useState("");
  const [email, setEmail] = useState("");
  const [id, setId] = useState(null);

  const dispatch = useDispatch();
  const navigate = useNavigate();
  const location = useLocation();

  useEffect(() => {
    if (location.state) {
      setId(location.state.id);
      setName(location.state.name);
      setAge(location.state.age);
      setEmail(location.state.email);
    }
  }, [location.state])

  const handleSubmit = (e) => {
    e.preventDefault();

    let obj = {
      id: id,
      name,
      age,
      email
    }
    dispatch(EDIT_USER(obj));
    navigate('/view')
  }

  return (
    <div align="center">
      <h1>Edit Users</h1>
      <form onSubmit={handleSubmit}>
        <table border={1} cellPadding="5px" cellSpacing="5px">
          <tbody>
            <tr>
              <td>Name:-</td>
              <td><input type="text" placeholder='Enter Name' value={name} onChange={(e) => setName(e.target.value)} /></td>
            </tr>
            <tr>
              <td>Email:-</td>
              <td><input type="email" placeholder='Enter Email' value={email} onChange={(e) => setEmail(e.target.value)} /></td>
            </tr>
            <tr>
              <td>Age:-</td>
              <td><input type="number" placeholder='Enter Age' value={age} onChange={(e) => setAge(e.target.value)} /></td>
            </tr>
            <tr>
              <td>⮞⮞⮞</td>
              <td><input type="submit" value="EDIT" /></td>
            </tr>
          </tbody>
        </table>
      </form>
      <hr />
      <Link to={'/view'}>VIEW</Link>
    </div>
  )
}

export default Edit
