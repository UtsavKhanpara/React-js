import React from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { Link, useNavigate } from 'react-router-dom'
import { DELETE_USER } from '../Redux/Action/CrudAction'

const View = () => {

  const record=useSelector(state=>state.crud.users)
  console.log(record)

  const dispatch=useDispatch();
  const navigate=useNavigate();
  return (
    <div align="center">
      <h1>View User</h1>
      <table border={1} cellPadding="5px" cellSpacing="5px">
          <thead>
            <tr>
              <th>Id</th>
              <th>Name</th>
              <th>Email</th>
              <th>Age</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            {
              record.map((val,index)=>{
                const{id,name,email,age}=val;
                return(
                  <>
                      <tr key={id}>
                        <td>{id}</td>
                        <td>{name}</td>
                        <td>{email}</td>
                        <td>{age}</td>
                        <td>
                          <button onClick={()=>navigate('/edit',{state:val})}>Edit</button>
                          <button onClick={()=>dispatch(DELETE_USER(id))}>Delete</button>
                          </td>
                      </tr>
                  </>
                )
              })
            }
          </tbody>
      </table>
      <hr />
      <Link to={'/'}>ADD</Link>
    </div>
  )
}

export default View
