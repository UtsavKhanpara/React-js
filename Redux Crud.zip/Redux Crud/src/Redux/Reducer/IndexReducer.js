import { combineReducers } from "redux";
import crudreducer from "./CrudReducer";

const rootreducer=combineReducers({
    crud:crudreducer
})
export default rootreducer;