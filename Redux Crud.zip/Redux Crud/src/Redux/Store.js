import { createStore } from "redux";
import rootreducer from "./Reducer/IndexReducer";

const store=createStore(rootreducer)
export default store;