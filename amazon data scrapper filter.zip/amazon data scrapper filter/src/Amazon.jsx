import React, { useEffect, useState } from 'react';
import { categoryData } from './categorydata';
import logo from '../assets/images/amazon_logo.png';
import './App.css';


const Amazon = () => {
  const [record, setRecord] = useState([]);
  const [filteredCategories, setFilteredCategories] = useState([]);
  const [categoryList, setCategoryList] = useState([]);
  const [selectedCategory, setSelectedCategory] = useState(null);

  const getAmazon = () => {
    fetch(`https://mocki.io/v1/6bdae5f6-c66e-4fef-ba7e-da7d4c90e7c1`)
      .then(res => res.json())
      .then((data) => {
        setRecord(data);

        const shopSection = data.find(item => item.section === 'shop');
        if (shopSection) {
          // ✅ Show only first 8 cards initially
          setFilteredCategories(shopSection.categories.slice(0, 8));

          // Collect unique category titles from categoryData keys
          setCategoryList(Object.keys(categoryData)); // Use keys from categoryData
        }
      })
      .catch((e) => {
        console.log(e);
      });
  };

  useEffect(() => {
    getAmazon();
  }, []);

  const filterByCategory = (category) => {
    const shopSection = record.find(item => item.section === 'shop');
    if (!shopSection) return;

    if (category === "All") {
      setFilteredCategories(shopSection.categories.slice(0, 8));
      setSelectedCategory(null);
    } else {
      const newFiltered = categoryData[category] || [];
      setFilteredCategories(newFiltered);
      setSelectedCategory(category);
    }
  };

  return (
    <div>
      {record.map((section, index) => {
        if (section.section === 'header') {
          return (
            <div key={index}>
              <header className="header">
                <img src={logo} width={100} style={{ height: 60 }} alt="" />
                <div className="address">
                  <span>{section.navbar.address.line1}</span>
                  <strong>{section.navbar.address.line2}</strong>
                </div>
                <div className="search-bar">
                  <select>
                    {section.navbar.search.dropdown.map((opt, i) => (
                      <option key={i}>{opt}</option>
                    ))}
                  </select>
                  <input type="text" placeholder={section.navbar.search.placeholder} />
                  <button className="search-button">🔍</button>
                </div>
                <div className="nav-options">
                  <div className="nav-item">
                    <span>{section.navbar.signin.line1}</span><br />
                    <strong>{section.navbar.signin.line2}</strong>
                  </div>
                  <div className="nav-item">
                    <span>{section.navbar.returns.line1}</span><br />
                    <strong>{section.navbar.returns.line2}</strong>
                  </div>
                  <div className="nav-item cart">
                    🛒 <strong style={{ marginLeft: "2px" }}>{section.navbar.cart}</strong>
                  </div>
                </div>
              </header>



              <nav className="panel">
                <div className="menu">{section.panel.menu}</div>
                <div className="options">
                  {section.panel.options.map((opt, i) => (
                    <span key={i}>{opt}</span>
                  ))}
                </div>
                <div className="highlight">{section.panel.highlight}</div>
              </nav>



              <div className="hero-section">
                <div className="hero-msg">
                  <p>You are on amazon.com. You can also shop on Amazon India for millions of Products with fast local
                    delivery. <a href="#"> Click here to go to amazon.in </a></p>
                </div>
              </div>
            </div>
          );
        }

        if (section.section === 'shop') {
          return (
            <section key={index} className="shop-section">
              {/* Filter Buttons */}
              <div className="filter-buttons">
                <button
                  className={selectedCategory === null ? "active" : ""}
                  onClick={() => filterByCategory("All")}
                >
                  All
                </button>
                {categoryList.map((cat, idx) => (
                  <button
                    key={idx}
                    className={selectedCategory === cat ? "active" : ""}
                    onClick={() => filterByCategory(cat)}
                  >
                    {cat}
                  </button>
                ))}
              </div>

              {/* Filtered Shop Cards */}
              <div className="shop-categories">
                {filteredCategories.map((category, catIndex) => (
                  <div key={catIndex} className="shop-card">
                    <h3>{category.title}</h3>
                    <img src={category.image} alt={category.title} />
                    <div className="shop-links">
                      <a href="#">See More</a>
                    </div>
                  </div>
                ))}
              </div>
            </section>
          );
        }



        if (section.section === 'footer') {
          return (
            <footer key={index} className="footer-section">
              <div className="back-to-top">Back to Top</div>

              <div className="footer-links">
                {section.infoSections.map((info, idx) => (
                  <div key={idx} className="footer-column">
                    <h3>{info.title}</h3>
                    <ul>
                      {info.links.map((link, liIdx) => (
                        <li key={liIdx}>{link}</li>
                      ))}
                    </ul>
                  </div>
                ))}
              </div>

              <div className="footer-bottom">
                {section.bottomLogo && (
                  <img src={logo} width={140} alt="" />
                )}
                <div className="footer-bottom-links">
                  {section.footerLinks.map((link, idx) => (
                    <span key={idx}>
                      {link}
                      {idx !== section.footerLinks.length - 1 && <span className="divider"> | </span>}
                    </span>
                  ))}
                </div>
                <p className="footer-copyright">
                  {section.copyright}
                </p>
              </div>
            </footer>
          );
        }

        return null;
      })}
    </div>
  );
};

export default Amazon;
