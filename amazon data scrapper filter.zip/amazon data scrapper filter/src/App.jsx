import React from 'react'
import Amazon from './Amazon'
const App = () => {
  return (
    <div> 
      <Amazon/>
    </div>
  )
}

export default App
